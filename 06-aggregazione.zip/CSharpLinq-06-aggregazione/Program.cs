﻿using CSharpLinq;
Console.OutputEncoding = System.Text.Encoding.UTF8;

// 06-01 GROUPBY 1
// raggruppa elementi secondo un criterio
// ritorna una lista di oggetti composti da:
// - proprietà Key (la chiave del criterio)
// - elenco degli elementi riconducibili a quella chiave

#region groupby-syntax
// raggruppiamo le parole in base alla lettera iniziale.
// vogliamo trovare tutte le possibili lettere iniziali delle parole nell'elenco
// e dividere le parole in sottoinsiemi che contengano, per ogni lettera iniziale, tutte le parole con quella lettera
string[] words = { "blueberry", "chimpanzee", "abacus", "banana", "apple", "cheese" };
var wordGroups = words.GroupBy(g => g[0]).Select(s => new { PrimaLettera = s.Key, Parole = s });

foreach (var g in wordGroups)
{
    Logger.Titolo($"Parole con lettera iniziale {g.PrimaLettera}:");
    foreach (var p in g.Parole)
    {
        Console.WriteLine(p);
    }
}
#endregion

// 06-02 GROUPBY 2
#region groupby-category
List<Product> products = Products.ProductList;

var productGroups = products.GroupBy(g => g.Category).Select(s => new { Categoria = s.Key, Prodotti = s });

foreach (var orderGroup in productGroups)
{
    Logger.Titolo($"Categoria {orderGroup.Categoria}:");
    foreach (var product in orderGroup.Prodotti)
    {
        Console.WriteLine($"\t{product}");
    }
}
#endregion

#region groupby-custom-comparer
string[] anagrams = { "from   ", " salt", " earn ", "  last   ", " near ", " form  " };

var wordGroups2 = anagrams.GroupBy(w => w.Trim(), new AnagramEqualityComparer());

foreach (var set in wordGroups2)
{
    Logger.Titolo(set.Key);
    foreach (var word in set)
    {
        Console.WriteLine(word.Trim());
    }
}
#endregion

// 06-03 JOIN
// unione di sorgenti dati diverse
#region cross-join
// combina ogni elemento della prima lista con ogni elemento della seconda lista
string[] categories = { "Beverages", "Seafood" };

// var q = from c in categories
//         join p in products on c equals p.Category
//         select (Category: c, p.ProductName);

var q = categories.Join(products, c => c, p => p.Category, (c, p) => new { Category = c, p.ProductName });

Logger.Titolo("Join Categorie/Prodotti");
foreach (var v in q)
{
    Console.WriteLine(v.ProductName + ": " + v.Category);
}

// secondo esempio
string[] warmCountries = { "Turkey", "Italy", "Spain", "Saudi Arabia", "Etiobia" };
string[] europeanCountries = { "Denmark", "Germany", "Italy", "Portugal", "Spain" };

var result = warmCountries.Join(europeanCountries, warm => warm, european => european, (warm, european) => warm);

Logger.Titolo("Join di paesi che sono sia caldi che Europei:");
foreach (var country in result)
{
    Console.WriteLine(country);
}
#endregion

// 06-04 GROUP JOIN
// Correla gli elementi di due sequenze in base all'uguaglianza delle chiavi e raggruppa i risultati.
#region group-join
string[] categories2 = { "Beverages", "Seafood", "Fingerfood" };
// var q2 = from c in categories
//          join p in products on c equals p.Category into ps
//          select (Category: c, Products: ps);

var q2 = categories2.GroupJoin(products, c => c, p => p.Category, (c, ps) => new { Category = c, Products = ps });

foreach (var v in q2)
{
    Logger.Titolo(v.Category + ":");
    foreach (var p in v.Products)
    {
        Console.WriteLine("\t" + p.ProductName);
    }
}
#endregion

#region left-outer-join
// comprende un gruppo (vuoto) anche degli elementi della lista di partenza che non trovano corrisponenza

var q3 = categories2.GroupJoin(products, c => c, p => p.Category, (c, ps) => new { Category = c, Products = ps.DefaultIfEmpty() });
foreach (var v in q3)
{
    Logger.Titolo(v.Category + ":");
    foreach (var p in v.Products)
    {
        Console.WriteLine("\t" + (p == null ? "(No products)" : p.ProductName));
    }
}
#endregion

// 06-05 COUNT, SUM
#region count-syntax
Logger.Titolo("Numero prodotti:");
Console.WriteLine(products.Count());
#endregion

#region count-conditional
Logger.Titolo("Numero prodotti in stock:");
Console.WriteLine(products.Where(x => x.UnitsInStock > 0).Count());
Console.WriteLine(products.Count(x => x.UnitsInStock > 0));
#endregion

#region nested-count
List<Customer> customers = Customers.CustomerList;
var orderCounts = customers.Select(c => new { c.CustomerID, OrderCount = c.Orders.Count() });

Logger.Titolo("Cliente ID e ordini:");
foreach (var customer in orderCounts)
{
    Console.WriteLine($"ID: {customer.CustomerID}, ordini: {customer.OrderCount}");
}
#endregion

#region grouped-count
// var categoryCounts = from p in products
//                      group p by p.Category into g
//                      select (Category: g.Key, ProductCount: g.Count());

var categoryCounts = products.GroupBy(p => p.Category).Select(g => new { Category = g.Key, ProductCount = g.Count() });

Logger.Titolo("Numero prodotti per categoria:");
foreach (var c in categoryCounts)
{
    Console.WriteLine($"Categoria: {c.Category}: Prodotti: {c.ProductCount}");
}
#endregion

#region sum-syntax
int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

double numSum = numbers.Sum();

Logger.Titolo("Somma dei numeri:");
Console.WriteLine(numSum);
#endregion

#region sum-property
var sommaOrdini = customers.Single(c => c.CustomerID == "ALFKI").Orders.Sum(s => s.Total);

Logger.Titolo("Totale ordini cliente ALFKI:");
Console.WriteLine(sommaOrdini.ToString("c"));
#endregion

#region grouped-sum
// var categoriesInStock = from p in products
//                         group p by p.Category into g
//                         select new { Category = g.Key, TotalUnitsInStock = g.Sum(p => p.UnitsInStock) };
var categoriesInStock = products.GroupBy(g => g.Category)
    .Select(g => new { Category = g.Key, TotalUnitsInStock = g.Sum(p => p.UnitsInStock) });

foreach (var group in categoriesInStock)
{
    Console.WriteLine($"Category: {group.Category}, Units in stock: {group.TotalUnitsInStock}");
}
#endregion

// 06-06 MAX, MIN, AVERAGE
// quello che diciamo per .Min(), si applica anche a .Max() e .Average()
// negli esempi li usiamo tutti e 3

#region min-syntax
int minNum = numbers.Min();
int maxNum = numbers.Max();
Logger.Titolo("Numero più piccolo");
Console.WriteLine(minNum);
Logger.Titolo("Numero più grande");
Console.WriteLine(maxNum);
#endregion

#region max-property
var ordineMaggiore = customers.Single(c => c.CustomerID == "ALFKI").Orders.Max(s => s.Total);

Logger.Titolo("Ordine maggiore cliente ALFKI:");
Console.WriteLine(ordineMaggiore.ToString("c"));
#endregion

#region average-grouped
// var categoriePrezzoMedio = from p in products
//                            group p by p.Category into g
//                            select new { Category = g.Key, AveragePrice = g.Average(p => p.UnitPrice) };

var categoriePrezzoMedio = products.GroupBy(g => g.Category)
    .Select(g => new { Category = g.Key, AveragePrice = g.Average(p => p.UnitPrice) });

Logger.Titolo("Prezzi medi per categoria:");
foreach (var c in categoriePrezzoMedio)
{
    Console.WriteLine($"Category: {c.Category}, Prezzo medio: {c.AveragePrice.ToString("c")}");
}
#endregion

#region min-each-group
// var categoriesMin = from p in products
//                     group p by p.Category into g
//                     let minPrice = g.Min(p => p.UnitPrice)
//                     select (Category: g.Key, ProdottiPiuEconomici: g.Where(p => p.UnitPrice == minPrice));

var categoriesMin = products.GroupBy(g => g.Category)
    .Select(g => new { Category = g.Key, ProdottiPiuEconomici = g.Where(p => p.UnitPrice == g.Min(p => p.UnitPrice)) });

// potrebbero esserci più prodotti per ogni categoria con lo stesso prezzo minimo
Logger.Titolo("Prodotto più economico per ogni categoria:");
foreach (var c in categoriesMin)
{
    Console.WriteLine($"Category: {c.Category}");
    foreach (var p in c.ProdottiPiuEconomici)
    {
        Console.WriteLine($"\tProduct: {p}");
    }
}
#endregion

// 06-07 DISTINCT, UNION, INTERSECT, EXCEPT
#region distinct-property-values
// ritorna valori unici (rimuove duplicati)
var categoryNames = products.Select(s => s.Category).Distinct();

Logger.Titolo("Categorie:");
foreach (var n in categoryNames)
{
    Console.WriteLine(n);
}
#endregion

#region union-query-results
// combina 2 liste e rimuove duplicati
var productFirstChars = products.Select(p => p.ProductName[0]);
var customerFirstChars = customers.Select(c => c.CompanyName[0]);

var uniqueFirstChars = productFirstChars.Union(customerFirstChars).OrderBy(o => o);

Logger.Titolo("Prime lettere uniche in Prodotti + Clienti:");
foreach (var ch in uniqueFirstChars)
{
    Console.WriteLine(ch);
}
#endregion

#region intersect-query-results
// prende solo gli elementi condivisi tra le 2 liste
var commonFirstChars = productFirstChars.Intersect(customerFirstChars).OrderBy(o => o);

Logger.Titolo("Prime lettere in comune in Prodotti + Clienti:");
foreach (var ch in commonFirstChars)
{
    Console.WriteLine(ch);
}
#endregion

#region except-query-results
// rimuove dalla prima lista gli elementi in comune con la seconda
var productOnlyFirstChars = productFirstChars.Except(customerFirstChars);

Logger.Titolo("Prime lettere in Prodotti, ma non in Clienti:");
foreach (var ch in productOnlyFirstChars)
{
    Console.WriteLine(ch);
}
#endregion

// 06-08 GENERATORI
#region generate-range
var numbers2 = Enumerable.Range(100, 50).Select(n => (Number: n, PariDispari: n % 2 == 1 ? "dispari" : "pari"));

foreach (var n in numbers2)
{
    Console.WriteLine($"Il numero {n.Number} è {n.PariDispari}.");
}
#endregion

#region generate-repeat
var parole = Enumerable.Repeat("ciao", 5);

foreach (var p in parole)
{
    Console.WriteLine(p);
}
#endregion

#region generate-empty
IEnumerable<string> retVal = Enumerable.Empty<string>();
#endregion

