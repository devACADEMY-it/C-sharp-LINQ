﻿using CSharpLinq;
Console.OutputEncoding = System.Text.Encoding.UTF8;
/*
Creiamo una classe che gestisca la ricerca e l'ordinamento di clienti e ordini.
La classe dovrà contenere un metodo statico che ritorni una lista di risultati.
I risultati dovranno essere paginati, cioè, definito un numero di elementi per pagina
dovremo potere richiedere pagine successive. (es: 1 di 5, 2 di 5, 3 di 5 ecc.)
I dati su cui ricercare saranno i soliti dati di clienti e ordini utilizzati durante il corso:
- Customers.CustomerList

I risultati dovranno avere le seguenti informazioni
- ID Cliente
- Nome Cliente
- Paese del Cliente (Country)
- Numero di ordini effettuati
- Somma degli importi di tutti gli ordini

I risultati saranno il frutto dell'applicazione dei seguenti criteri
che si basano sulle informazioni di cui sopra:

Criteri di ricerca
- ID Cliente
- Nome Cliente
- Paese del Cliente
Criteri di ordinamento
- Nome Cliente
- Paese del Cliente
- Numero di ordini effettuati
- Somma degli importi di tutti gli ordini
Criteri di paginazione
- ElementiPerPagina
- PaginaCorrente

Una volta chiamato il metodo, stampiamo i risultati a console.

FACOLTATIVO: trovare un modo per caricare la pagina successiva dei risultati premendo un tasto in console
fino ad esaurimento delle pagine
*/
var customers = (IEnumerable<Customer>)Customers.CustomerList;

Console.WriteLine("Buon lavoro");