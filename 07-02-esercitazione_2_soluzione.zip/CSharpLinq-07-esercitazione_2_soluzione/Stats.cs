namespace CSharpLinq
{
    public class Stats
    {
        public static IEnumerable<ClienteOrdine> GetOrdini(out int TotalCount, string FiltroCampo = "", string FiltroValore = "", string OrdinamentoCampo = "Nome", bool OrdinamentoAscendente = true, int PaginaCorrente = 1, int ElementiPerPagina = 5)
        {
            IEnumerable<ClienteOrdine> retVal = Enumerable.Empty<ClienteOrdine>();
            var customers = (IEnumerable<Customer>)Customers.CustomerList;
            TotalCount = 0;

            try
            {
                // proiezione
                retVal = customers.Select(s => new ClienteOrdine()
                {
                    Id = s.CustomerID,
                    Nome = s.CompanyName,
                    Paese = s.Country,
                    NumeroOrdini = s.Orders.Count(),
                    TotaleOrdini = s.Orders.Sum(s => s.Total)
                });

                // filtri
                switch (FiltroCampo)
                {
                    case "Id":
                        retVal = retVal.Where(c => c.Id == FiltroValore);
                        break;
                    case "Nome":
                        retVal = retVal.Where(c => c.Nome.ToLower().Contains(FiltroValore.ToLower()));
                        break;
                    case "Paese":
                        retVal = retVal.Where(c => c.Paese.ToLower() == FiltroValore.ToLower());
                        break;
                }

                // ordinamento
                switch (OrdinamentoCampo)
                {
                    case "Nome":
                        retVal = OrdinamentoAscendente ? retVal.OrderBy(o => o.Nome) : retVal.OrderByDescending(o => o.Nome);
                        break;
                    case "Paese":
                        retVal = OrdinamentoAscendente ? retVal.OrderBy(o => o.Paese) : retVal.OrderByDescending(o => o.Paese);
                        break;
                    case "NumeroOrdini":
                        retVal = OrdinamentoAscendente ? retVal.OrderBy(o => o.NumeroOrdini) : retVal.OrderByDescending(o => o.NumeroOrdini);
                        break;
                    case "TotaleOrdini":
                        retVal = OrdinamentoAscendente ? retVal.OrderBy(o => o.TotaleOrdini) : retVal.OrderByDescending(o => o.TotaleOrdini);
                        break;
                }

                TotalCount = retVal.Count();
                
                // paginazione
                retVal = retVal.Skip((PaginaCorrente - 1) * ElementiPerPagina).Take(ElementiPerPagina);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                retVal = Enumerable.Empty<ClienteOrdine>();
            }

            return retVal;
        }
    }

    public class ClienteOrdine
    {
        public string Id { get; set; } = string.Empty;
        public string Nome { get; set; } = string.Empty;
        public string Paese { get; set; } = string.Empty;
        public int NumeroOrdini { get; set; }
        public decimal TotaleOrdini { get; set; }

    }
}