﻿using CSharpLinq;

// 01-02 PROGETTO DI LAVORO
Console.OutputEncoding = System.Text.Encoding.UTF8;

// DataSources, Linq to Objects
var customers = Customers.CustomerList;
var categories = Products.CategoryList;
var products = Products.ProductList;

Console.WriteLine("Customers: " + customers.Count);
Console.WriteLine("Categories: " + categories.Count);
Console.WriteLine("Products: " + products.Count);
Console.WriteLine();

// Test
// Movies + IMDbApiLib
var movies = Movies.GetMovies();

// 01-03 TIPOLOGIE DI SINTASSI
// Esistono 2 modi per scrivere query Linq, identici a livello di performance e di risultato
// 1. Sintassi di Query (un po' più leggibile)
// 2. Sintassi di metodo (più completa)
int[] numbers = { 5, 10, 8, 3, 6, 12 };

//Query syntax:
var numQuery1 =
    from num in numbers
    where num % 2 == 0
    orderby num
    select num;

//Method syntax:
var numQuery2 = numbers.Where(num => num % 2 == 0).OrderBy(n => n);

Logger.Titolo("Query");
foreach (int i in numQuery1)
{
    Console.Write(i + " ");
}
Console.Write(System.Environment.NewLine);
Logger.Titolo("Method");
foreach (int i in numQuery2)
{
    Console.Write(i + " ");
}
Console.Write(System.Environment.NewLine);
Console.WriteLine();

// 01-04 INTERFACCE
// La sintassi Linq si applica a qualsiasi oggetto C# che implmenti
// IEnumerable o IQueryable (e derivate es: IOrderedEnumerable)
// e spesso ritorna IEnumerable o IQueryable affinchè possiamo concatenare istruzioni
// IEnumerable si applica ad oggetti caricati in memoria
// IQueryable si applica a Database

Console.WriteLine(numbers is IEnumerable<int>);

var strings = new List<string>() { "ciao", "come", "va" };
Console.WriteLine(strings is IEnumerable<string>);

var result = strings.Where(x => x.StartsWith("c"));
foreach (var r in result)
{
    Console.WriteLine(r);
}

var result2 =
    from s in strings
    where s.StartsWith("c")
    select s;
foreach (var r in result2)
{
    Console.WriteLine(r);
}