namespace CSharpLinq
{
    public class Cliente
    {
        public Cliente(string id, string nome, string indirizzo, IEnumerable<OrdineEuro> ordini)
        {
            Id = id;
            Nome = nome;
            Indirizzo = indirizzo;
            Ordini = ordini;
        }

        public string Id { get; set; }
        public string Nome { get; set; }
        public string Indirizzo { get; set; }
        public IEnumerable<OrdineEuro> Ordini { get; set; }
    }
}