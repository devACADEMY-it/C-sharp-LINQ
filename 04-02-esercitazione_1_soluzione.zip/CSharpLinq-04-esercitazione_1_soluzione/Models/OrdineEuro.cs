namespace CSharpLinq
{
    public class OrdineEuro
    {
        public OrdineEuro(DateTime data, decimal totaleEuro)
        {
            Data = data;
            TotaleEuro = totaleEuro;
        }
        
        public DateTime Data { get; set; }
        public decimal TotaleEuro { get; set; }
    }
}