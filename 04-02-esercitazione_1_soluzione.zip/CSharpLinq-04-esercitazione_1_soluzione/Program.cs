﻿using CSharpLinq;
Console.OutputEncoding = System.Text.Encoding.UTF8;
/*
1. Creare una classe OrdineEuro con costruttore e con le proprietà
   - decimal TotaleEuro
   - DateTime Data
2. Creare una classe Cliente con costruttore e con le proprietà
   - string Id
   - string Nome
   - string Indirizzo
   - IEnumerable<OrdineEuro> Ordini
3. cercare tutti i clienti USA con nome che cominci con la lettera L
4. proiettare (Select) il risultato sulle nuove classi create (Cliente, OrdineEuro) specificando
   - Cliente.Indirizzo = Address + PostalCode + City
   - Oridne.TotaleEuro = Total * 0.9 (tasso di cambiop Dollaro => Euro)
5. per ogni cliente loggare:
   - una riga con Nome e Indirizzo del cliente
   - una riga per ogni ordine del cliente con: TAB + Data + TotaleEuro (con simbolo della valuta)
*/
var customers = Customers.CustomerList;

var clienti = customers
    .Where(c => c.Country == "USA" && c.CompanyName.StartsWith("L"))
    .Select(s => new Cliente(s.CustomerID,
                             s.CompanyName,
                             $"{s.Address}, {s.PostalCode} {s.City}",
                             s.Orders.Select(o => new OrdineEuro(o.OrderDate, o.Total * 0.9M))
                             ));

foreach (var c in clienti)
{
    Console.WriteLine($"{c.Nome} - {c.Indirizzo}");
    foreach (var o in c.Ordini)
    {
        Console.WriteLine($"\t{o.Data.ToShortDateString()} - {o.TotaleEuro.ToString("c")}");
    }
}

