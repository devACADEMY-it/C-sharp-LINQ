namespace CSharpLinq
{
    public class Logger
    {
        public static void Titolo(string Titolo)
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine(Titolo);
            Console.ResetColor();
        }
    }
}