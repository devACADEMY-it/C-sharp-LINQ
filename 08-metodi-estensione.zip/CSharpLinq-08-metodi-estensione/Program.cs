﻿using CSharpLinq;
Console.OutputEncoding = System.Text.Encoding.UTF8;

// 08-01 INTRODUZIONE
// I metodi di estensione consentono di "aggiungere" metodi ai tipi esistenti
// senza creare un nuovo tipo derivato, ricompilare o modificare in altro modo il tipo originale
// I metodi di estensione sono metodi statici, ma vengono chiamati come se fossero metodi di istanza nel tipo esteso. 
// I metodi di estensione più comuni sono gli operatori di query standard LINQ che aggiungono funzionalità di query
// ai tipi System.Collections.IEnumerable e System.Collections.Generic.IEnumerable<T> esistenti.

int[] ints = { 10, 45, 15, 39, 21, 26 };
var result = ints.OrderBy(g => g); // F12 (Menu Go => Go to Definition)
foreach (var i in result)
{
    Console.Write(i + " ");
}
Console.WriteLine();

// 08-02 ESTENSIONE PER STRINGA
// Extensions.cs
var str = "Ciao, come va?";

Logger.Titolo("Parole nella frase");
foreach (var w in str.ToWords())
{
    Console.WriteLine(w);
}

// 08-03 ESTENSIONE PER MODELLO
// utile quando vogliamo mappare un modello ad un modello diverso
// Extensions.cs
var customers = Customers.CustomerList;
var alfki = customers.Single(c => c.CustomerID == "ALFKI");

CustomerStats alfkiStats = alfki.ToCustomerStats();
Logger.Titolo("Statistiche di ALFKI");
Console.WriteLine($"Id: {alfkiStats.Id} - Ordini: {alfkiStats.NumeroOrdini} - Totale: {alfkiStats.TotaleAcquistato.ToString("c")}");

Logger.Titolo("Statistiche utenti WA");
var waStats = customers.Where(c => c.Region == "WA").Select(s => s.ToCustomerStats());
foreach (var c in waStats)
{
    Console.WriteLine($"Id: {c.Id} - Ordini: {c.NumeroOrdini,2} - Totale: {c.TotaleAcquistato.ToString("c")}");
}