using System.Text.RegularExpressions;

namespace CSharpLinq
{
    public static class StringExtensions
    {
        public static string[] ToWords(this string str)
        {
            return Regex.Split(str, @"[\s\W]+").Where(s => !string.IsNullOrEmpty(s)).ToArray();
        }
    }

    public static class CustomerExtensions
    {
        public static CustomerStats ToCustomerStats(this Customer customer)
        {
            return new CustomerStats()
            {
                Id = customer.CustomerID,
                Name = customer.CompanyName,
                TotaleAcquistato = customer.Orders.Sum(s => s.Total),
                NumeroOrdini = customer.Orders.Count()
            };
        }
    }
}