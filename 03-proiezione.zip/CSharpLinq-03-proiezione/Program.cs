﻿using CSharpLinq;
Console.OutputEncoding = System.Text.Encoding.UTF8;

// 03-01 SELECT 1
// proietta/trasforma i valori in altri valori
// map in altri linguaggi
#region select-syntax
int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

var numsPlusOne = numbers.Select(n => n + 1);

Logger.Titolo("Numeri + 1:");
foreach (var i in numsPlusOne)
{
    Console.WriteLine(i);
}
#endregion

#region select-property
var products = Products.ProductList;
var productNames = products.Select(p => p.ProductName);
Logger.Titolo("Solo nomi prodotti");
foreach (var productName in productNames)
{
    Console.WriteLine(productName);
}
#endregion

#region select-transform
string[] strings = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };

var textNums = numbers.Select(n => strings[n]);

Logger.Titolo("Numeri in stringa");
foreach (var s in textNums)
{
    Console.WriteLine(s);
}
#endregion

// 03-02 SELECT TIPI
#region select-case-anonymous
var gigi = new { Nome = "Gigi", Congome = "Verdi" };
Console.WriteLine(gigi.Nome);

string[] words = { "aPPLE", "BlUeBeRrY", "cHeRry" };

var upperLowerWords = words.Select(w => new { Upper = w.ToUpper(), Lower = w.ToLower() });
Logger.Titolo("Uppercase/Lowercase");
foreach (var ul in upperLowerWords)
{
    Console.WriteLine($"Uppercase: {ul.Upper}, Lowercase: {ul.Lower}");
}
#endregion

#region select-new-type
// classe Dummy
var digitOddEvens = numbers.Select(n => new Dummy(strings[n], (n % 2 == 0)));
Logger.Titolo("Cifra/Pari/Dispari");
foreach (var d in digitOddEvens)
{
    Console.WriteLine($"La cifra {d.Digit} è {(d.Even ? "pari" : "dispari")}.");
}
#endregion

// 03-03 SELECT AVANZATO
#region select-subset-properties
// sintassi alternativa con tipo anonimo
var productInfos = products.Select(p => new { p.ProductName, p.Category, Price = p.UnitPrice });
Logger.Titolo("Prodotti");
foreach (var productInfo in productInfos)
{
    Console.WriteLine($"{productInfo.ProductName} è nella categoria {productInfo.Category} e costa {productInfo.Price:C} per unità.");
}

// sintassi alternativa con tuple
var productInfosTuple = products.Select(p => (p.ProductName, p.Category, Price: p.UnitPrice));
Logger.Titolo("Prodotti Tuple");
foreach (var productInfo in productInfosTuple)
{
    Console.WriteLine($"{productInfo.ProductName} è nella categoria {productInfo.Category} e costa {productInfo.Price:C} per unità.");
}
#endregion

#region select-with-index
var numsInPlace = numbers.Select((num, index) => (Num: num, AlSuoPosto: (num == index)));

Logger.Titolo("Numero al suo indice?");
foreach (var n in numsInPlace)
{
    Console.WriteLine($"{n.Num}: {n.AlSuoPosto}");
}
#endregion

#region select-with-where
var lowNums = numbers.Where(x => x < 5).Select(n => strings[n]);
Logger.Titolo("Numeri < 5:");
foreach (var num in lowNums)
{
    Console.WriteLine(num);
}
#endregion

//03-04 SELECT MANY
#region select-many-sottoproprietà
string[] ids = { "ALFKI", "ANATR" };
var customers = Customers.CustomerList;
var ordersC = customers.Where(x => ids.Contains(x.CustomerID)).SelectMany(c => c.Orders);

Logger.Titolo("Ordini di clienti con ID");
foreach (var order in ordersC)
{
    Console.WriteLine($"Order: {order.OrderID}, Total value: {order.Total}");
}
#endregion

#region multiple-where-clauses
DateTime cutoffDate = new DateTime(1997, 1, 1);

// corrspettivo con query syntax
// var ordersWA2 = from c in customers
//                 where c.Region == "WA"
//                 from o in c.Orders
//                 where o.OrderDate >= cutoffDate
//                 select new { c.CustomerID, o.OrderID, o.OrderDate };

var ordersWA = customers
    .SelectMany(c => c.Orders, (c, o) => new { c.CustomerID, c.Region, o.OrderID, o.OrderDate })
    .Where(x => x.Region == "WA" && x.OrderDate >= cutoffDate);

Logger.Titolo("Clienti WA");
foreach (var order in ordersWA)
{
    Console.WriteLine($"Customer: {order.CustomerID}, Order: {order.OrderID}, OrderDate: {order.OrderDate.ToShortDateString()}");
}
#endregion
