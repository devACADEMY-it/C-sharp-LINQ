using System.Text.RegularExpressions;

namespace CSharpLinq
{
    public class IgnoraNumeriComparer : IComparer<string>
    {
        public int Compare(string? x, string? y)
        {
            if (!string.IsNullOrEmpty(x))
            {
                x = Regex.Replace(x, @"\d", "").Trim();
            }

            if (!string.IsNullOrEmpty(y))
            {
                y = Regex.Replace(y, @"\d", "").Trim();
            }

            return string.Compare(x, y, StringComparison.OrdinalIgnoreCase);
        }
    }
}