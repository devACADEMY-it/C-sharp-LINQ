﻿using CSharpLinq;
Console.OutputEncoding = System.Text.Encoding.UTF8;

// 05-01 ORDERBY
// ordinamento elementi
#region orderby-syntax
string[] words = { "cherry", "apple", "blueberry" };
var sortedWords = words.OrderBy(o => o);

Logger.Titolo("Parole ordinate:");
foreach (var w in sortedWords)
{
    Console.WriteLine(w);
}
#endregion

#region orderby-property
List<Product> products = Products.ProductList;
var sortedProducts = products.OrderBy(o => o.ProductName);

Logger.Titolo("Prodotti ordinati per nome:");
foreach (var product in sortedProducts)
{
    Console.WriteLine(product);
}
#endregion

#region orderby-descending-property
var sortedProductsByStock = products.OrderByDescending(o => o.UnitsInStock);

Logger.Titolo("Prodotti ordinati per quantità in stock:");
foreach (var product in sortedProductsByStock)
{
    Console.WriteLine(product);
}
#endregion

#region thenby-ordering


var sortedProductsByCategoryAndPrice =
    products.OrderBy(o => o.Category)
            .ThenByDescending(o => o.UnitPrice);

Logger.Titolo("Prodotti ordinati per categoria e prezzo unitario discendente:");
foreach (var product in sortedProductsByCategoryAndPrice)
{
    Console.WriteLine(product);
}
#endregion

// 05-02 COMPARATORE CUSTOM
#region orderby-custom-comparer
// IgnoraNumeriComparer.cs
string[] words2 = { "1 tigre", "2 cane", "5 albatros", "4 gatto", "3 zebra", "6 elefante" };
Logger.Titolo("Parole ordinate:");
foreach (var word in words2.OrderBy(o => o))
{
    Console.WriteLine(word);
}

var sortedWords2 = words2.OrderBy(a => a, new IgnoraNumeriComparer());
Logger.Titolo("Parole ordinate ignorando i numeri:");
foreach (var word in sortedWords2)
{
    Console.WriteLine(word);
}
#endregion

// 05-03 TAKE, SKIP
#region take-syntax
int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

var first3Numbers = numbers.Take(3);

Logger.Titolo("Primi 3 numeri:");
foreach (var n in first3Numbers)
{
    Console.WriteLine(n);
}
#endregion

#region take-where-orderby
List<Customer> customers = Customers.CustomerList;

var customersAndOrders = customers.SelectMany(c => c.Orders, (c, o) => new { c.CustomerID, c.Region, o.OrderID, o.OrderDate, o.Total });
var primi3WAOrders = customersAndOrders.Where(x => x.Region == "WA").OrderByDescending(o => o.Total).Take(3);

Logger.Titolo("Primi 3 ordini per importo a WA:");
foreach (var order in primi3WAOrders)
{
    Console.WriteLine(order);
}
#endregion

#region skip-syntax
var tuttiTranneIPrimi4 = numbers.Skip(7);
Logger.Titolo("Tutti tranne i primi 7:");
foreach (var n in tuttiTranneIPrimi4)
{
    Console.WriteLine(n);
}
#endregion

#region skip-take-where
var secondi3WAOrders = customersAndOrders.Where(x => x.Region == "WA").OrderByDescending(o => o.Total).Skip(3).Take(3);
Logger.Titolo("Secondi 3 ordini per importo a WA:");
foreach (var order in secondi3WAOrders)
{
    Console.WriteLine(order);
}
#endregion