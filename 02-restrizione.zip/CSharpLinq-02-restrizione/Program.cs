﻿using CSharpLinq;
Console.OutputEncoding = System.Text.Encoding.UTF8;

// 02-01 WHERE 1

#region where condizione
int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

var lowNums = numbers.Where(x => x < 5);
Logger.Titolo("Numeri < 5:");
foreach (var x in lowNums)
{
    Console.WriteLine(x);
}
#endregion

#region where condizione proprietà
var products = Products.ProductList;
var soldOutProducts = products.Where(x => x.UnitsInStock == 0);
Logger.Titolo("Prodotti esauriti:");
foreach (var product in soldOutProducts)
{
    Console.WriteLine($"{product.ProductName}");
}
#endregion

#region where condizione multipla
var prezzo = 50.00M;
var expensiveInStockProducts = products.Where(x => x.UnitsInStock > 0 && x.UnitPrice > prezzo);

// oppure where concatenati
// expensiveInStockProducts = products.Where(x => x.UnitsInStock > 0);
// expensiveInStockProducts = expensiveInStockProducts.Where(x => x.UnitPrice > prezzo);

Logger.Titolo($"Prodotti in stock che costano più di {prezzo}:");
foreach (var product in expensiveInStockProducts)
{
    Console.WriteLine($"{product.ProductName}");
}
#endregion

// 02-02 WHERE 2
#region where con sottoelementi
var waCustomers = Customers.CustomerList.Where(x => x.Region == "WA");
Logger.Titolo("Clienti di Washington con ordini:");
foreach (var customer in waCustomers)
{
    Console.WriteLine($"Cliente {customer.CustomerID}: {customer.CompanyName}");
    foreach (var order in customer.Orders)
    {
        Console.WriteLine($"  Ordine {order.OrderID}: {order.OrderDate}");
    }
}
#endregion

#region where indice
string[] digits = { "zero", "uno", "due", "tre", "quattro", "cinque", "sei", "sette", "otto", "nove" };
var shortDigits = digits.Where((digit, index) => digit.Length < index);

Logger.Titolo("Numeri corti:");
foreach (var d in shortDigits)
{
    Console.WriteLine($"La parola {d} è più corta del suo valore.");
}
#endregion

#region where in elenco
string[] numbersToFind = { "tre", "sei", "dodici" };

var numsFound = digits.Where(x => numbersToFind.Contains(x));
Logger.Titolo("Numeri da elenco:");
foreach (var d in numsFound)
{
    Console.WriteLine(d);
}
#endregion

// 02-03 FIRST, LAST, ELEMENTAT, SINGLE
#region primo elemento
Product productInStock = products.Where(x => x.UnitsInStock > 0).First();
Logger.Titolo("Primo prodotto in stock");
Console.WriteLine(productInStock);
#endregion

#region primo elemento match
string[] strings = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
string startsWithO = strings.First(s => s.StartsWith("o"));
Logger.Titolo($"Prima stringa che comincia per 'o'");
Console.WriteLine(startsWithO);
#endregion

#region primo o default
int[] numbersEmpty = { };

int firstNumOrDefault = numbersEmpty.FirstOrDefault();
Logger.Titolo("Primo numero o default");
Console.WriteLine(firstNumOrDefault);
#endregion

#region primo match o default
Product? product789 = products.FirstOrDefault(p => p.ProductID == 789);
Logger.Titolo("Primo prodotto o default");
Console.WriteLine($"Esiste prodotto 789 : {product789 != null}");
#endregion

// Last vale come First ma prende l'ultimo elemento

#region element-at
int secondLowNumber = numbers.Where(x => x > 5).ElementAt(1);
Logger.Titolo("Secondo numero > 5");
Console.WriteLine(secondLowNumber);
#endregion

#region single
try
{
    // var unProdotto = products.Single(x => x.UnitsInStock > 0);
    var unProdotto = products.SingleOrDefault(p => p.ProductID == 1);
    Logger.Titolo("Un prodotto");
    Console.WriteLine(unProdotto);
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}

#endregion

// 02-04 ALL, ANY, CONTAINS
#region any matches
string[] words = { "uno", "due", "tre", "quattro" };

bool lm3 = words.Any(w => w.Length > 3);
Logger.Titolo("C'è una parola lunga più di 3?");
Console.WriteLine(lm3);
#endregion

#region all matches
bool l3 = words.All(w => w.Length == 3);
Logger.Titolo("Tutte le parole sono lunghe 3?");
Console.WriteLine(l3);
#endregion

#region contains
bool cDue = words.Contains("due"); // come any, ma accetta un valore invece che lambda
Logger.Titolo("Contiene la parola 'due'?");
Console.WriteLine(cDue);
#endregion